package com.curious365.ifa.dao;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.curious365.ifa.IntelligentFinancialAccountingApplicationTests;
import com.curious365.ifa.common.Constants;
import com.curious365.ifa.dto.Transaction;

public class AccountDAOTest extends IntelligentFinancialAccountingApplicationTests {
	
	@Autowired
	private AccountingDAO accountingDAO;
	
	@Test
	public void testGetTransaction(){
		Transaction record = accountingDAO.getTransactionById(1051);
		Assert.assertNotNull("Transaction cannot be null", record);
		log.info(record);
	}
	
	@Test
	public void testCreateTransaction(){
		Transaction record = new Transaction();
		record.setTransactionCustomerName("vasanth narayanan");
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MMM/yyyy");
		DateFormat newformatter ; 
		Date newdate = null ; 
		newformatter = new SimpleDateFormat("dd/MM/yyyy");
		try {
			newdate = (Date)newformatter.parse("20/10/2015");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String dateString=formatter.format(newdate);
		record.setTransactionDate(dateString);
		record.setTransactionAmount(1000);
		record.setIsIncome(Constants.CHAR_Y);
		record.setActiveFlag(Constants.ACTIVE);
		boolean result = accountingDAO.createTransaction(record);
		Assert.assertTrue("Succefully inserted", result);
	}

	public AccountingDAO getAccountingDAO() {
		return accountingDAO;
	}

	public void setAccountingDAO(AccountingDAO accountingDAO) {
		this.accountingDAO = accountingDAO;
	}

}
