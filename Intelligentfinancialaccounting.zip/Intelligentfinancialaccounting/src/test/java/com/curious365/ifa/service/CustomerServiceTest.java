package com.curious365.ifa.service;


import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.curious365.ifa.IntelligentFinancialAccountingApplicationTests;
import com.curious365.ifa.common.Constants;

public class CustomerServiceTest extends IntelligentFinancialAccountingApplicationTests {
	
	@Autowired
	private CustomerService customerService;
	
	@Test
	public void testCustomerCount(){
		Map<String,Object> map = customerService.getCustomerRowCount();
		Assert.assertNotNull("Row count details shouldn't be null", map);
		Assert.assertNotSame("Error occured while retrieving row count", map.get(Constants.ERROR), Constants.YES);
	}

	public CustomerService getCustomerService() {
		return customerService;
	}

	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}

}
