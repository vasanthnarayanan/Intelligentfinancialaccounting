package com.curious365.ifa.service;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import com.curious365.ifa.IntelligentFinancialAccountingApplicationTests;
import com.curious365.ifa.dto.Content;
import com.curious365.ifa.util.JacksonConversion;

public class AccountServiceTest extends IntelligentFinancialAccountingApplicationTests{
	
	@Autowired
	private AccountingService accountingService;

	public AccountingService getAccountingService() {
		return accountingService;
	}

	public void setAccountingService(AccountingService accountingService) {
		this.accountingService = accountingService;
	}
	
	@Test
	public void testListSales(){
		List<Content> sales = accountingService.listAllSales(0, 10);
		Assert.notNull(sales, "sales list should not be null");
		String convertedJson = null;
		try{
			convertedJson = JacksonConversion.toJSON(sales);
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("Sales list <<>> "+convertedJson);
	}

}
