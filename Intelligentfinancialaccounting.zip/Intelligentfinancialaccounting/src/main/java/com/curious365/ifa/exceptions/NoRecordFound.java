package com.curious365.ifa.exceptions;

public class NoRecordFound extends Exception {

	public NoRecordFound(String message) {
		super(message);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -7953773973877567128L;

}
