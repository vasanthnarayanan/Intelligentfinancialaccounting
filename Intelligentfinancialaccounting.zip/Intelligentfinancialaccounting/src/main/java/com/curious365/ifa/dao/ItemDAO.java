package com.curious365.ifa.dao;

import java.util.List;

public interface ItemDAO {
	public List<String> listItemLike(String query);
}
