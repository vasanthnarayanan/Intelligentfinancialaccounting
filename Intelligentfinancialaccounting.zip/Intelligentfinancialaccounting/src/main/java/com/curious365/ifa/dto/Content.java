package com.curious365.ifa.dto;
public class Content{
private String type;
private long recordId;
private double cost;
private long pieces;
private double total;
private String date;
private String customerId;
private long itemId;

public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public long getRecordId() {
	return recordId;
}
public void setRecordId(long recordId) {
	this.recordId = recordId;
}
public double getCost() {
	return cost;
}
public void setCost(double cost) {
	this.cost = cost;
}
public long getPieces() {
	return pieces;
}
public void setPieces(long pieces) {
	this.pieces = pieces;
}
public double getTotal() {
	return total;
}
public void setTotal(double total) {
	this.total = total;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getCustomerId() {
	return customerId;
}
public void setCustomerId(String customerId) {
	this.customerId = customerId;
}
public long getItemId() {
	return itemId;
}
public void setItemId(long itemId) {
	this.itemId = itemId;
}
}
