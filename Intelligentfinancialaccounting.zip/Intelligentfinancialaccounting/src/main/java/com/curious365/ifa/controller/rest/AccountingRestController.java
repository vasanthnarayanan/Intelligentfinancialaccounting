package com.curious365.ifa.controller.rest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.curious365.ifa.dto.Content;
import com.curious365.ifa.service.AccountingService;

@RestController
public class AccountingRestController {
	private Log log = LogFactory.getLog(AccountingRestController.class);
	
	@Autowired
	private AccountingService accountingService;

	public AccountingService getAccountingService() {
		return accountingService;
	}

	public void setAccountingService(AccountingService accountingService) {
		this.accountingService = accountingService;
	}
	
	@RequestMapping("/getActiveAccountRowCount")
	public Map<String,Object> getActiveAccountRowCount(@RequestParam("customername") String customerName){
		log.debug("entering..");
		return accountingService.getAccountDetailsRowCount(customerName);
	}
	
	@RequestMapping("/getActiveSalesRowCount")
	public Map<String,Object> getActiveSalesRowCount(){
		log.debug("entering..");
		return accountingService.getSalesRowCount();
	}
	
	@RequestMapping("/getActivePurchaseRowCount")
	public Map<String,Object> getActivePurchaseRowCount(){
		log.debug("entering..");
		return accountingService.getPurchaseRowCount();
	}
	
	@RequestMapping("/getActiveFaultRowCount")
	public Map<String,Object> getActiveFaultRowCount(){
		log.debug("entering..");
		return accountingService.getFaultRowCount();
	}
	
	@RequestMapping(value = "/listSales")
	public List<Content> listSales(@RequestParam("pageNo")int pageNo,@RequestParam("recPerPage")int recPerPage){
		log.debug("entering..");
		List<Content> salesList = new ArrayList<Content>();
		int strtRow=(pageNo*recPerPage)-recPerPage;
		int endRow=(pageNo*recPerPage);
		try {
			salesList = accountingService.listAllSales(strtRow, endRow);
		} catch (Exception e) {
			e.printStackTrace();
		};
		return salesList;
	}
	
	@RequestMapping(value = "/listPurchase")
	public List<Content> listPurchase(@RequestParam("pageNo")int pageNo,@RequestParam("recPerPage")int recPerPage){
		log.debug("entering..");
		List<Content> salesList = new ArrayList<Content>();
		int strtRow=(pageNo*recPerPage)-recPerPage;
		int endRow=(pageNo*recPerPage);
		try {
			salesList = accountingService.listAllPurchase(strtRow, endRow);
		} catch (Exception e) {
			e.printStackTrace();
		};
		return salesList;
	}

	@RequestMapping(value = "/listFault")
	public List<Content> listFault(@RequestParam("pageNo")int pageNo,@RequestParam("recPerPage")int recPerPage){
		log.debug("entering..");
		List<Content> salesList = new ArrayList<Content>();
		int strtRow=(pageNo*recPerPage)-recPerPage;
		int endRow=(pageNo*recPerPage);
		try {
			salesList = accountingService.listAllFault(strtRow, endRow);
		} catch (Exception e) {
			e.printStackTrace();
		};
		return salesList;
	}

}
