package com.curious365.ifa.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.curious365.ifa.common.Constants;
import com.curious365.ifa.dao.CustomerDAO;
import com.curious365.ifa.dto.Customer;
import com.curious365.ifa.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDAO customerDAO;

	public CustomerDAO getCustomerDAO() {
		return customerDAO;
	}

	public void setCustomerDAO(CustomerDAO customerDAO) {
		this.customerDAO = customerDAO;
	}

	@Override
	public Map<String, Object> getCustomerRowCount() {
		Map<String,Object> map = new HashMap<String, Object>();
		try{
			long rowCount = customerDAO.getActiveCustomerRowCount();
			if(rowCount == 0){
				map.put(Constants.ERROR, Constants.YES);
			}else{
				map.put(Constants.ROWCOUNT, rowCount);
			}
		}catch(Exception e){
			map.put(Constants.ERROR, Constants.YES);
		}
		return map;
	}

	@Override
	public List<Customer> getActiveCustomers(String sortType,int strtRow,int endRow) {
		return customerDAO.getCustomers(sortType, strtRow, endRow);
	}

	@Override
	public String checkCustomerNameAvailability(String customerName) {
		String availability = Constants.UNAVAILABLE;
		if(StringUtils.hasText(customerName.trim()) && customerDAO.checkCustomerNameAvailability(customerName)){
			availability = Constants.AVAILABLE;
		}
		return availability;
	}

	@Override
	public boolean addNewCustomer(Customer customer) {
		return customerDAO.addNewCustomer(customer);
	}

	@Override
	public Map<String, Object> populateAutocomplete(String query) {
		StringBuilder sb = new StringBuilder();
		Map<String,Object> similarCustomers = new HashMap<String,Object>(); 
		sb.append(query);
		sb.append(Constants.PERCENTAGE);
		List<String> customers = customerDAO.listCustomerLike(sb.toString());
		similarCustomers.put(Constants.QUERY, query);
		similarCustomers.put(Constants.SUGGESTIONS, customers);
		similarCustomers.put(Constants.DATA, customers);
		return similarCustomers;
	}

	@Override
	public Customer getCustomerById(String customerId) {
		return customerDAO.getCustomerById(customerId);
	}

	@Override
	public Map<String, Object> populateIdAutocomplete(String query) {
		StringBuilder sb = new StringBuilder();
		Map<String,Object> similarCustomers = new HashMap<String,Object>(); 
		sb.append(query);
		sb.append(Constants.PERCENTAGE);
		List<String> customers = customerDAO.listCustomerIdLike(sb.toString());
		similarCustomers.put(Constants.QUERY, query);
		similarCustomers.put(Constants.SUGGESTIONS, customers);
		similarCustomers.put(Constants.DATA, customers);
		return similarCustomers;
	}

	@Override
	public boolean editCustomer(Customer customer) {
		return customerDAO.editCustomer(customer);
	}

	@Override
	public boolean removeCustomer(String customerId) {
		return customerDAO.removeCustomer(customerId);
	}
	
}
