package com.curious365.ifa.dao;

import java.util.List;

import com.curious365.ifa.dto.Customer;

public interface CustomerDAO {
	public Long getActiveCustomerRowCount() throws Exception;
	public List<Customer> getCustomers(String sortType, int strtRow, int endRow);
	public boolean checkCustomerNameAvailability(String customerName);
	public boolean addNewCustomer(Customer bean);
	public List<String> listCustomerLike(String query);
	public Customer getCustomerById(String customerId);
	public List<String> listCustomerIdLike(String query);
	public boolean editCustomer(Customer bean);
	public boolean removeCustomer(String customerId);
}
