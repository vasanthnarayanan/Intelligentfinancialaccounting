package com.curious365.ifa.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.curious365.ifa.common.Constants;
import com.curious365.ifa.dao.ItemDAO;
import com.curious365.ifa.service.ItemService;

@Service
public class ItemServiceImpl implements ItemService {
	
	@Autowired
	private ItemDAO itemDAO;
	
	public ItemDAO getItemDAO() {
		return itemDAO;
	}

	public void setItemDAO(ItemDAO itemDAO) {
		this.itemDAO = itemDAO;
	}

	@Override
	public Map<String, Object> populateAutocomplete(String query) {
		StringBuilder sb = new StringBuilder();
		Map<String,Object> similarItems = new HashMap<String,Object>(); 
		sb.append(query);
		sb.append(Constants.PERCENTAGE);
		List<String> items = itemDAO.listItemLike(sb.toString());
		similarItems.put(Constants.QUERY, query);
		similarItems.put(Constants.SUGGESTIONS, items);
		similarItems.put(Constants.DATA, items);
		return similarItems;
	}

	

}
