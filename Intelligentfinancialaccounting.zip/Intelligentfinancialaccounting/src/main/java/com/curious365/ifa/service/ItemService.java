package com.curious365.ifa.service;

import java.util.Map;

public interface ItemService {
	public Map<String,Object> populateAutocomplete(String query);
}
