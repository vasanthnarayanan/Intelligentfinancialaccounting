package com.curious365.ifa.controller.rest;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.curious365.ifa.common.Constants;
import com.curious365.ifa.dto.Customer;
import com.curious365.ifa.service.CustomerService;

@RestController
public class CustomerRestController {
	private Log log = LogFactory.getLog(CustomerRestController.class);
	
	@Autowired
	private CustomerService customerService;
	
	@RequestMapping("/getActiveCustomerRowCount")
	public Map<String,Object> getActiveCustomerRowCount(){
		log.debug("entering..");
		return customerService.getCustomerRowCount();
	}
	
	@RequestMapping("/getActiveCustomers")
	public List<Customer> getActiveCustomers(@RequestParam("sortType") String sortType,@RequestParam("page") int page,@RequestParam("count") int count){
		log.debug("entering..");
		int strtRow=(page*count)-count;
		int endRow=(page*count);
		return customerService.getActiveCustomers(sortType, strtRow, endRow);
	}
	
	@RequestMapping("/checkCustomerName")
	public String checkCustomerName(@RequestParam("customername") String customerName){
		log.debug("entering..");
		return customerService.checkCustomerNameAvailability(customerName);
	}
	
	@RequestMapping("/listCustomersLike")
	public Map<String,Object> populateAutocomplete(@RequestParam("query") String query){
		log.debug("entering..");
		return customerService.populateAutocomplete(query);
	}
	
	@RequestMapping("/listCustomerIdLike")
	public Map<String,Object> populateIdAutocomplete(@RequestParam("query") String query){
		log.debug("entering..");
		return customerService.populateIdAutocomplete(query);
	}
	
	@RequestMapping("/getCustomerById")
	public Customer getCustomerById(@RequestParam("customerid")String customerId){
		log.debug("entering..");
		Customer customer = null;
		if(StringUtils.hasText(customerId)){
			customer = customerService.getCustomerById(customerId);	
		}
		
		if(null != customer){
			customer.setFlag(Constants.ONE);
		}else{
			customer = new Customer();
			customer.setName(Constants.EMPTY_STRING);
			customer.setCustomerId(Constants.EMPTY_STRING);
			customer.setFlag(Constants.ZERO);
		}
		return customer;
	}
	
	@RequestMapping(value="/removeCustomer", method=RequestMethod.POST)
	public boolean removeCustomer(@RequestParam("customerid")String customerId){
		log.debug("entering..");
		return customerService.removeCustomer(customerId);
	}


	public CustomerService getCustomerService() {
		return customerService;
	}

	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}
}
