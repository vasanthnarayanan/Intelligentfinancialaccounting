package com.curious365.ifa.dao;

import java.util.List;
import java.util.Map;

import com.curious365.ifa.dto.Content;
import com.curious365.ifa.dto.Transaction;

public interface AccountingDAO {
	public Long getActiveAccountsRowCount(String customerName) throws Exception;
	public List<String> listPageDates(String customerName, int strtRow, int endRow);
	public List<Double> listPrevPageBalance(String customerName, int strtRow, int endRow, String prevDate);
	public List<Map<String,Object>> listCurrDateSalesRec(String customerName, int strtRow, int endRow, String date);
	public List<Map<String,Object>> listCurrDatePurchaseRec(String customerName, int strtRow, int endRow, String date);
	public List<Map<String,Object>> listCurrDateFaultRec(String customerName, int strtRow, int endRow, String date);
	public List<Map<String,Object>> listCurrDateIncomeRec(String customerName, int strtRow, int endRow, String date);
	public List<Map<String,Object>> listCurrDateExpenditureRec(String customerName, int strtRow, int endRow, String date);
	public List<Double> listGrossCalculations(String customerName);
	public Transaction getTransactionById(long transactionId);
	public boolean createTransaction(Transaction record);
	public boolean editTransaction(Transaction record);
	public boolean softDeleteTransaction(long transactionId);
	public Long getActiveSalesRowCount() throws Exception;
	public Long getActivePurchaseRowCount() throws Exception;
	public Long getActiveFaultRowCount() throws Exception;
	public List<Content> listAllSale(int strtRow,int endRow);
	public List<Content> listAllPurchase(int strtRow,int endRow);
	public List<Content> listAllFault(int strtRow,int endRow);
}
