package com.curious365.ifa.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.velocity.tools.ConversionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.curious365.ifa.dao.AccountingDAO;
import com.curious365.ifa.dto.Accounts;
import com.curious365.ifa.dto.Content;
import com.curious365.ifa.dto.Transaction;
import com.curious365.ifa.exceptions.NoRecordFound;
import com.curious365.ifa.service.AccountingService;

import static com.curious365.ifa.common.Constants.*; 

@Service
public class AccountingServiceImpl implements AccountingService {

	@Autowired
	private AccountingDAO accountingDAO;

	public AccountingDAO getAccountingDAO() {
		return accountingDAO;
	}

	public void setAccountingDAO(AccountingDAO accountingDAO) {
		this.accountingDAO = accountingDAO;
	}

	@Override
	public Accounts getCustomerAccountDetails(String customerName, int strtRow,
			int endRow) throws Exception {
			Accounts result = new Accounts();
		    List<String> currDates=null;
		    List<String> dispDates=new ArrayList<String>();
		    List<String> prevDates=null;
		    /* --- Previous page balance --- */
		    double prevPageBalance=0;
		    if(strtRow>=5)
		    {
		    	int prevStrtRow=0;
		    	int prevEndRow=endRow-5;
		    	
		    	prevDates = accountingDAO.listPageDates(customerName, prevStrtRow, prevEndRow);
			    
			    if(null == prevDates || prevDates.isEmpty())
			    {
			    	throw new NoRecordFound("No records found");
			    }
			    
			    for (String prevDate: prevDates) {
					List<Double> prevPageBalances = accountingDAO.listPrevPageBalance(customerName, prevStrtRow, prevEndRow, prevDate);
					for (Double dateWiseBalance : prevPageBalances) {
						prevPageBalance = prevPageBalance + dateWiseBalance;
					}
				}
			   
		    }
		    /* --- Current page details --- */
		    currDates = accountingDAO.listPageDates(customerName, strtRow, endRow);
		    
		    if(null == currDates || currDates.isEmpty())
		    {
		    	throw new NoRecordFound("No records found");
		    }
		    
		    double totalSalesSum=0;
		    double totalExpenditureSum=0;
		    
		    for (String currentDate : currDates) {
		    	SimpleDateFormat formatter= 
		    			new SimpleDateFormat("dd/MM/yyyy");
		    	DateFormat newformatter ; 
				Date newdate ; 
				newformatter = new SimpleDateFormat("dd/MMM/yyyy");
				newdate = (Date)newformatter.parse(currentDate);
				String dispCurrentDate=formatter.format(newdate);
				dispDates.add(dispCurrentDate);
				

		    	double dailySalesSum=0;
		    	double dailyPurchaseSum=0;
		    	double dailyFaultSum=0;
		    	double dailyIncomeSum=0;
		    	double dailyExpenditureSum=0;
		    	double dailySum=0;
		    	
		    	List<Content> content=new ArrayList<Content>();
		    	
		    	List<Map<String,Object>> currDateSalesList = accountingDAO.listCurrDateSalesRec(customerName, strtRow, endRow, currentDate);
		    	
		    	for (Map<String, Object> currDateSales : currDateSalesList) {
		    		Content sales = new Content();
		    		sales.setType(SALES);
		    		sales.setRecordId(ConversionUtils.toNumber(currDateSales.get(SALES_RECORD_ID)).longValue());
		    		sales.setCost(ConversionUtils.toNumber(currDateSales.get(SALES_COST)).doubleValue());
		    		sales.setPieces(ConversionUtils.toNumber(currDateSales.get(SALES_PIECES)).longValue());
		    		sales.setTotal(ConversionUtils.toNumber(currDateSales.get(SALES_RECORD_TOTAL)).doubleValue());
		    		content.add(sales);
		    		dailySalesSum = dailySalesSum + ConversionUtils.toNumber(currDateSales.get(SALES_RECORD_TOTAL)).doubleValue();
				}
		    	
		    	List<Map<String,Object>> currDatePurchaseList = accountingDAO.listCurrDatePurchaseRec(customerName, strtRow, endRow, currentDate);
		    	
		    	for (Map<String, Object> currDatePurchase : currDatePurchaseList) {
		    		Content purchase = new Content();
		    		purchase.setType(PURCHASE);
		    		purchase.setRecordId(ConversionUtils.toNumber(currDatePurchase.get(PURCHASE_RECORD_ID)).longValue());
		    		purchase.setCost(ConversionUtils.toNumber(currDatePurchase.get(PURCHASE_COST)).doubleValue());
		    		purchase.setPieces(ConversionUtils.toNumber(currDatePurchase.get(PURCHASE_PIECES)).longValue());
		    		purchase.setTotal(ConversionUtils.toNumber(currDatePurchase.get(PURCHASE_RECORD_TOTAL)).doubleValue());
		    		content.add(purchase);
		    		dailyPurchaseSum = dailyPurchaseSum - ConversionUtils.toNumber(currDatePurchase.get(PURCHASE_RECORD_TOTAL)).doubleValue();
				}

		    	List<Map<String,Object>> currDateFaultList = accountingDAO.listCurrDateFaultRec(customerName, strtRow, endRow, currentDate);
		    	
		    	for (Map<String, Object> currDateFault : currDateFaultList) {
		    		Content fault = new Content();
		    		fault.setType(FAULT);
		    		fault.setRecordId(ConversionUtils.toNumber(currDateFault.get(FAULT_RECORD_ID)).longValue());
		    		fault.setCost(ConversionUtils.toNumber(currDateFault.get(FAULT_COST)).doubleValue());
		    		fault.setPieces(ConversionUtils.toNumber(currDateFault.get(FAULT_PIECES)).longValue());
		    		fault.setTotal(ConversionUtils.toNumber(currDateFault.get(FAULT_RECORD_TOTAL)).doubleValue());
		    		content.add(fault);
		    		dailyFaultSum = dailyFaultSum - ConversionUtils.toNumber(currDateFault.get(FAULT_RECORD_TOTAL)).doubleValue();
				}
		    	
		    	List<Map<String,Object>> currDateIncomeList = accountingDAO.listCurrDateIncomeRec(customerName, strtRow, endRow, currentDate);
		    	
		    	for (Map<String, Object> currDateIncome : currDateIncomeList) {
		    		Content income = new Content();
		    		income.setType(INCOME);
		    		income.setRecordId(ConversionUtils.toNumber(currDateIncome.get(TRANSACTION_RECORD_ID)).longValue());
		    		income.setTotal(ConversionUtils.toNumber(currDateIncome.get(TRANSACTION_AMOUNT)).doubleValue());
		    		content.add(income);
		    		dailyIncomeSum = dailyIncomeSum - ConversionUtils.toNumber(currDateIncome.get(TRANSACTION_AMOUNT)).doubleValue();
				}

		    	List<Map<String,Object>> currDateExpenditureList = accountingDAO.listCurrDateExpenditureRec(customerName, strtRow, endRow, currentDate);
		    	
		    	for (Map<String, Object> currDateExpenditure : currDateExpenditureList) {
		    		Content expenditure = new Content();
		    		expenditure.setType(EXPENDITURE);
		    		expenditure.setRecordId(ConversionUtils.toNumber(currDateExpenditure.get(TRANSACTION_RECORD_ID)).longValue());
		    		expenditure.setTotal(ConversionUtils.toNumber(currDateExpenditure.get(TRANSACTION_AMOUNT)).doubleValue());
		    		content.add(expenditure);
		    		dailyExpenditureSum = dailyExpenditureSum + ConversionUtils.toNumber(currDateExpenditure.get(TRANSACTION_AMOUNT)).doubleValue();
				}
		    	
		    	totalSalesSum=totalSalesSum+dailySalesSum+dailyExpenditureSum;// sub-total
		    	totalExpenditureSum=totalExpenditureSum+(dailyPurchaseSum+dailyFaultSum+dailyIncomeSum);// sub-total
		    	result.getContent().put(dispCurrentDate, content);
			}
		    
		    
		    
		    // calculating the total sum of pages
		    int rsfinalinc=0;
		    double grossSum=0;
		    double grossPurchase=0;
		    double grossFault=0;
		    double grossIncome=0;
		    double grossExpenditure=0;
		    double grossTotal=0;
		    List<Double> grossCalculationsList = accountingDAO.listGrossCalculations(customerName);
		    for (Double gross : grossCalculationsList) {
		    	switch(rsfinalinc){
		    	case 0:
		    		grossSum = gross!=null?gross:0;
		    		break;
		    	case 1:
		    		grossPurchase = gross!=null?gross:0;
		    		break;
		    	case 2:
		    		grossFault = gross!=null?gross:0;
		    		break;
		    	case 3:
		    		grossIncome = gross!=null?gross:0;
		    		break;
		    	case 4:
		    		grossExpenditure = gross!=null?gross:0;
		    		break;
		    	}
				rsfinalinc++;
			}
		    grossTotal = grossSum+grossExpenditure-grossPurchase-grossFault-grossIncome;// final sum
		    
		    if(prevPageBalance<0)
		    {
		    	totalExpenditureSum=totalExpenditureSum+prevPageBalance;
		    }
		    else
		    {
		    	totalSalesSum=totalSalesSum+prevPageBalance;
		    }
		    
		    double total=totalSalesSum+totalExpenditureSum;// page sum
		    
		    result.getDispDates().addAll(dispDates);
		    result.setTotal(total);
		    result.setTotalSalesSum(totalSalesSum);
		    result.setTotalExpenditureSum(totalExpenditureSum);
		    result.setGrossTotal(grossTotal);
		    result.setPrevPageBalance(prevPageBalance);
 		return result;
	}

	@Override
	public Map<String, Object> getAccountDetailsRowCount(String customerName) {
		Map<String,Object> map = new HashMap<String, Object>();
		try{
			long rowCount = accountingDAO.getActiveAccountsRowCount(customerName);
			if(rowCount == 0){
				map.put(ERROR, YES);
			}else{
				map.put(ROWCOUNT, rowCount);
			}
		}catch(Exception e){
			map.put(ERROR, YES);
		}
		return map;
	}

	@Override
	public boolean createTransaction(Transaction record) {
		return accountingDAO.createTransaction(record);
	}

	@Override
	public boolean editTransaction(Transaction record) {
		return accountingDAO.editTransaction(record);
	}

	@Override
	public boolean removeTransaction(long transactionId) {
		return accountingDAO.softDeleteTransaction(transactionId);
	}

	@Override
	public Map<String, Object> getSalesRowCount() {
		Map<String,Object> map = new HashMap<String, Object>();
		try{
			long rowCount = accountingDAO.getActiveSalesRowCount();
			if(rowCount == 0){
				map.put(ERROR, YES);
			}else{
				map.put(ROWCOUNT, rowCount);
			}
		}catch(Exception e){
			map.put(ERROR, YES);
		}
		return map;
	}

	@Override
	public Map<String, Object> getPurchaseRowCount() {
		Map<String,Object> map = new HashMap<String, Object>();
		try{
			long rowCount = accountingDAO.getActivePurchaseRowCount();
			if(rowCount == 0){
				map.put(ERROR, YES);
			}else{
				map.put(ROWCOUNT, rowCount);
			}
		}catch(Exception e){
			map.put(ERROR, YES);
		}
		return map;
	}

	@Override
	public Map<String, Object> getFaultRowCount() {
		Map<String,Object> map = new HashMap<String, Object>();
		try{
			long rowCount = accountingDAO.getActiveFaultRowCount();
			if(rowCount == 0){
				map.put(ERROR, YES);
			}else{
				map.put(ROWCOUNT, rowCount);
			}
		}catch(Exception e){
			map.put(ERROR, YES);
		}
		return map;
	}

	@Override
	public List<Content> listAllSales(int strtRow,int endRow) {
		return accountingDAO.listAllSale(strtRow,endRow);
	}

	@Override
	public List<Content> listAllPurchase(int strtRow,int endRow) {
		return accountingDAO.listAllPurchase(strtRow,endRow);
	}

	@Override
	public List<Content> listAllFault(int strtRow,int endRow) {
		return accountingDAO.listAllFault(strtRow,endRow);
	}
}
