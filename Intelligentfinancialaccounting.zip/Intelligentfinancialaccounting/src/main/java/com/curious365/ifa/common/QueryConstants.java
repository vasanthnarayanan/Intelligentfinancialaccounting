package com.curious365.ifa.common;

public class QueryConstants {

	/**
	 * CustomerDAO
	 */
	
	public static final String COUNT_ACTIVE_CUSTOMERS = "select count(*) from customer where activeflag=?";
	public static final String LIST_CUSTOMERS_WT_PAGING = "select * from ( select a.*, ROWNUM rnum from (select * from customer where activeflag=?) a where ROWNUM <= ?)where rnum  > ?";
	public static final String LIST_CUSTOMERS_ASC_WT_PAGING = "select * from ( select a.*, ROWNUM rnum from (select * from customer where activeflag=? order by name) a where ROWNUM <= ?)where rnum  > ?";
	public static final String LIST_CUSTOMERS_DESC_WT_PAGING = "select * from ( select a.*, ROWNUM rnum from (select * from customer where activeflag=? order by name desc) a where ROWNUM <= ?)where rnum  > ?";
	public static final String CHECK_CUSTOMERNAME_AVAILABILITY = "select count(*) from customer where activeflag=? and name=?";
	public static final String INSERT_CUSTOMER = "insert into customer values(id_sequence.nextVal,?,?)";
	public static final String LIST_CUSTOMERS_LIKE = "select name from customer where activeflag=? and name like ?";
	public static final String LIST_CUSTOMER_IDS_LIKE = "select customerid from customer where activeflag=? and customerid like ?";
	public static final String GET_CUSTOMER_BY_ID = "select * from customer where activeflag=? and customerid=?";
	public static final String UPDATE_CUSTOMER = "update customer set name=? where customerid=?";
	public static final String SOFT_DELETE_CUSTOMER = "update customer set activeflag=? where customerid=?";
	
	/**
	 * ItemDAO
	 */
	
	public static final String LIST_ITEMS_LIKE = "select id from item where activeflag=? and id like ?";
	
	/**
	 * AccountingDAO
	 */
	public static final String COUNT_ACTIVE_ACCOUNT_DETAILS = "select count(*) from ((select salesdate from sales where salescustomername=? and activeflag=?)" +
			" union (select purchasedate from purchase where purchasecustomername=? and activeflag=?)" +
					" union (select faultdate from fault where faultcustomername=? and activeflag=?)" +
							" union (select transactiondate from transaction where transactioncustomername=? and activeflag=?))";
	public static final String LIST_PREV_DATEWISE_BALANCE = "select sum(total) from (select salescost*salespieces as total from sales where salescustomername=? and salesdate=? and activeflag=?" +
    		" union all select purchasecost*-purchasepieces  from purchase where purchasecustomername=? and purchasedate=? and activeflag=?" +
			" union all select faultcost*-faultpieces  from fault where faultcustomername=? and faultdate=? and activeflag=?" +
					" union all select -transactionamount  from transaction where transactioncustomername=? and transactiondate=? and is_income=? and activeflag=?" +
							" union all select transactionamount  from transaction where transactioncustomername=? and transactiondate=? and is_income=? and activeflag=?)";
	public static final String LIST_PAGE_DATES = "select dates from ( select a.*, ROWNUM rnum from (select to_char(salesdate,'DD/MON/YYYY') as dates from ((select salesdate from sales where salescustomername=? and activeflag=?)" +
			" union (select purchasedate from purchase where purchasecustomername=? and activeflag=?)" +
			" union (select faultdate from fault where faultcustomername=? and activeflag=?)" +
			" union (select transactiondate from transaction where transactioncustomername=? and activeflag=?))) a where ROWNUM <= ?)where rnum  > ?";
	public static final String LIST_CURR_DATEWISE_SALES_BALANCE = "select salesrecordid,salespieces,salescost,salespieces*salescost as salesrecordtotal from sales where salesdate=? and salescustomername=? and activeflag=?";
	public static final String LIST_CURR_DATEWISE_PURCHASE_BALANCE = "select purchaserecordid,purchasepieces,purchasecost,purchasepieces*purchasecost as purchaserecordtotal from purchase where purchasedate=? and purchasecustomername=? and activeflag=?";
	public static final String LIST_CURR_DATEWISE_FAULT_BALANCE = "select faultrecordid,faultpieces,faultcost,faultpieces*faultcost as faultrecordtotal from fault where faultdate=? and faultcustomername=? and activeflag=?";
	public static final String LIST_CURR_DATEWISE_INCOME_BALANCE = "select transactionrecordid,transactionamount from transaction where transactiondate=? and transactioncustomername=? and is_income=? and activeflag=?";
	public static final String LIST_CURR_DATEWISE_EXPENDITURE_BALANCE = "select transactionrecordid,transactionamount from transaction where transactiondate=? and transactioncustomername=? and is_income=? and activeflag=?";
	public static final String LIST_TOTAL_BALANCE = "select sum(salescost*salespieces) from sales where salescustomername=? and activeflag=?" +
    		" union all select sum(purchasecost*purchasepieces)  from purchase where purchasecustomername=? and activeflag=?" +
			" union all select sum(faultcost*faultpieces)  from fault where faultcustomername=? and activeflag=?" +
					" union all select sum(transactionamount)  from transaction where transactioncustomername=? and is_income=? and activeflag=?" +
							" union all select sum(transactionamount)  from transaction where transactioncustomername=? and is_income=? and activeflag=?";
	/*
	 * TransactionSheet
	 */
	public static final String GET_TRANSACTION = "select * from transaction where transactionrecordid=? and activeflag=?";
	public static final String CREATE_TRANSACTION = "insert into transaction values(transactionrecordid_sequence.nextVal,?,?,?,?,?)";
	public static final String UPDATE_TRANSACTION = "update transaction set transactiondate=?,transactioncustomername=?,transactionamount=?,is_income=? where transactionrecordid=?";
	public static final String SOFT_DELETE_TRANSACTION  = "update transaction set activeflag=? where transactionrecordid=?";
	
	/**
	 * SalesSheet
	 */
	public static final String COUNT_ACTIVE_SALES = "select count(*) from sales where activeflag=? and salescustomername in (select name from customer where activeflag=?)";
	public static final String LIST_ALL_SALES = "select * from ( select a.*, ROWNUM rnum from (select salesrecordid,to_char(salesdate,'DD/MM/YYYY')\"date\",salescustomername,salesitemid,salespieces,salescost from sales where activeflag=? and salescustomername in (select name from customer where activeflag=?) order by salesdate) a where ROWNUM <= ?)where rnum  > ?";
	
	/**
	 * PurchaseSheet
	 */
	public static final String COUNT_ACTIVE_PURCHASE = "select count(*) from purchase where activeflag=? and purchasecustomername in (select name from customer where activeflag=?)";
	public static final String LIST_ALL_PURCHASE = "select * from ( select a.*, ROWNUM rnum from (select purchaserecordid,to_char(purchasedate,'DD/MM/YYYY')\"date\",purchasecustomername,purchaseitemid,purchasepieces,purchasecost from purchase where activeflag=? and purchasecustomername in (select name from customer where activeflag=?) order by purchasedate) a where ROWNUM <= ?)where rnum  > ?";
	
	
	/**
	 * FaultSheet
	 */
	public static final String COUNT_ACTIVE_FAULT = "select count(*) from fault where activeflag=? and faultcustomername in (select name from customer where activeflag=?)";
	public static final String LIST_ALL_FAULT = "select * from ( select a.*, ROWNUM rnum from (select faultrecordid,to_char(faultdate,'DD/MM/YYYY')\"date\",faultcustomername,faultitemid,faultpieces,faultcost from fault where activeflag=? and faultcustomername in (select name from customer where activeflag=?) order by faultdate) a where ROWNUM <= ?)where rnum  > ?";
	
}
