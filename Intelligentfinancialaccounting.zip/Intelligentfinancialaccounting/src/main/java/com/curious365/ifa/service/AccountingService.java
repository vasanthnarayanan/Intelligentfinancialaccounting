package com.curious365.ifa.service;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.curious365.ifa.dto.Accounts;
import com.curious365.ifa.dto.Content;
import com.curious365.ifa.dto.Transaction;

public interface AccountingService {
	public Map<String,Object> getAccountDetailsRowCount(String customerName);
	public Accounts getCustomerAccountDetails(String customerName,int strtRow,int endRow) throws ParseException, Exception;
	public boolean createTransaction(Transaction record);
	public boolean editTransaction(Transaction record);
	public boolean removeTransaction(long transactionId);
	public Map<String,Object> getSalesRowCount();
	public Map<String,Object> getPurchaseRowCount();
	public Map<String,Object> getFaultRowCount();
	public List<Content> listAllSales(int strtRow,int endRow);
	public List<Content> listAllPurchase(int strtRow,int endRow);
	public List<Content> listAllFault(int strtRow,int endRow);
}
