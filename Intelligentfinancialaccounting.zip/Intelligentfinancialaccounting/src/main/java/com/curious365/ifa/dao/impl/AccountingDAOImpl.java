package com.curious365.ifa.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.curious365.ifa.RowMapper.FaultRowMapper;
import com.curious365.ifa.RowMapper.PurchaseRowMapper;
import com.curious365.ifa.RowMapper.SalesRowMapper;
import com.curious365.ifa.common.Constants;
import com.curious365.ifa.common.QueryConstants;
import com.curious365.ifa.dao.AccountingDAO;
import com.curious365.ifa.dto.Content;
import com.curious365.ifa.dto.Transaction;

@Repository
public class AccountingDAOImpl implements AccountingDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}


	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	@Override
	public List<Double> listPrevPageBalance(String customerName, int strtRow, int endRow,
			String prevDate) {
		List<Double> prevPageBalances = null;
		try{
			prevPageBalances = jdbcTemplate.queryForList(QueryConstants.LIST_PREV_DATEWISE_BALANCE,
										Double.class,new Object[]{customerName,prevDate,Constants.ACTIVE,
										customerName,prevDate,Constants.ACTIVE,
										customerName,prevDate,Constants.ACTIVE,
										customerName,prevDate,Constants.CHAR_Y,Constants.ACTIVE,
										customerName,prevDate,Constants.CHAR_N,Constants.ACTIVE});
		}catch(Exception e){
			e.printStackTrace();
		}

		return prevPageBalances;
	}


	@Override
	public List<String> listPageDates(String customerName, int strtRow,
			int endRow) {
		List<String> dates = null;
		try{
			dates = jdbcTemplate.queryForList(QueryConstants.LIST_PAGE_DATES,
										String.class,new Object[]{customerName,Constants.ACTIVE,customerName,
										Constants.ACTIVE,customerName,Constants.ACTIVE,customerName,Constants.ACTIVE,endRow,strtRow});
		}catch(Exception e){
			e.printStackTrace();
		}
		return dates;
	}


	@Override
	public List<Map<String, Object>> listCurrDateSalesRec(String customerName,
			int strtRow, int endRow, String date) {
		List<Map<String,Object>> currDateSalesRec = null;
		try{
			currDateSalesRec = jdbcTemplate.queryForList(QueryConstants.LIST_CURR_DATEWISE_SALES_BALANCE,new Object[]{date,customerName,Constants.ACTIVE});
		}catch(Exception e){
			e.printStackTrace();
		}

		return currDateSalesRec;
	}


	@Override
	public List<Map<String, Object>> listCurrDatePurchaseRec(
			String customerName, int strtRow, int endRow, String date) {
		List<Map<String,Object>> currDatePurchaseRec = null;
		try{
			currDatePurchaseRec = jdbcTemplate.queryForList(QueryConstants.LIST_CURR_DATEWISE_PURCHASE_BALANCE,new Object[]{date,customerName,Constants.ACTIVE});
		}catch(Exception e){
			e.printStackTrace();
		}

		return currDatePurchaseRec;
	}


	@Override
	public List<Map<String, Object>> listCurrDateFaultRec(String customerName,
			int strtRow, int endRow, String date) {
		List<Map<String,Object>> currDateFaultRec = null;
		try{
			currDateFaultRec = jdbcTemplate.queryForList(QueryConstants.LIST_CURR_DATEWISE_FAULT_BALANCE,new Object[]{date,customerName,Constants.ACTIVE});
		}catch(Exception e){
			e.printStackTrace();
		}

		return currDateFaultRec;
	}


	@Override
	public List<Map<String, Object>> listCurrDateIncomeRec(
			String customerName, int strtRow, int endRow, String date) {
		List<Map<String,Object>> currDateExpenditureRec = null;
		try{
			currDateExpenditureRec = jdbcTemplate.queryForList(QueryConstants.LIST_CURR_DATEWISE_INCOME_BALANCE,new Object[]{date,customerName,Constants.CHAR_Y,Constants.ACTIVE});
		}catch(Exception e){
			e.printStackTrace();
		}

		return currDateExpenditureRec;
	}
	
	@Override
	public List<Map<String, Object>> listCurrDateExpenditureRec(
			String customerName, int strtRow, int endRow, String date) {
		List<Map<String,Object>> currDateExpenditureRec = null;
		try{
			currDateExpenditureRec = jdbcTemplate.queryForList(QueryConstants.LIST_CURR_DATEWISE_EXPENDITURE_BALANCE,new Object[]{date,customerName,Constants.CHAR_N,Constants.ACTIVE});
		}catch(Exception e){
			e.printStackTrace();
		}

		return currDateExpenditureRec;
	}


	@Override
	public List<Double> listGrossCalculations(String customerName) {
		List<Double> grossCalculations = null;
		try{	
			grossCalculations = jdbcTemplate.queryForList(QueryConstants.LIST_TOTAL_BALANCE,Double.class,new Object[]{customerName,Constants.ACTIVE,
					customerName,Constants.ACTIVE,
					customerName,Constants.ACTIVE,
					customerName,Constants.CHAR_Y,Constants.ACTIVE,
					customerName,Constants.CHAR_N,Constants.ACTIVE});
		}catch(Exception e){
			e.printStackTrace();
		}

		return grossCalculations;
	}


	@Override
	public Long getActiveAccountsRowCount(String customerName) throws Exception {
		return jdbcTemplate.queryForObject(QueryConstants.COUNT_ACTIVE_ACCOUNT_DETAILS,Long.class,new Object[]{customerName,Constants.ACTIVE,
																												customerName,Constants.ACTIVE,
																												customerName,Constants.ACTIVE,
																												customerName,Constants.ACTIVE});
	}


	@Override
	public Transaction getTransactionById(long transactionId) {
		Transaction record = null;
		try{
			record = jdbcTemplate.queryForObject(QueryConstants.GET_TRANSACTION,  new BeanPropertyRowMapper<Transaction>(Transaction.class),new Object[]{transactionId,Constants.ACTIVE});
		}catch(Exception e){
			
		}
		return record;
	}


	@Override
	public boolean createTransaction(Transaction record) {
		int flag = jdbcTemplate.update(
				QueryConstants.CREATE_TRANSACTION,
				new Object[] { record.getTransactionDate(),
						record.getTransactionCustomerName(),
						record.getTransactionAmount(), record.getIsIncome(),
						Constants.ACTIVE });
		if(flag>0){
			return true;
		}else{
			return false;
		}
	}


	@Override
	public boolean editTransaction(Transaction record) {
		int flag = jdbcTemplate.update(
				QueryConstants.UPDATE_TRANSACTION,
				new Object[] { record.getTransactionDate(),
						record.getTransactionCustomerName(),
						record.getTransactionAmount(), record.getIsIncome(),
						record.getTransactionRecordId() });
		if(flag>0){
			return true;
		}else{
			return false;
		}
	}


	@Override
	public boolean softDeleteTransaction(long transactionId) {
		int flag = jdbcTemplate.update(
				QueryConstants.SOFT_DELETE_TRANSACTION,
				new Object[] { Constants.ACTIVE, transactionId });
		if(flag>0){
			return true;
		}else{
			return false;
		}
	}


	@Override
	public Long getActiveSalesRowCount() throws Exception {
		return jdbcTemplate.queryForObject(QueryConstants.COUNT_ACTIVE_SALES,Long.class,new Object[]{Constants.ACTIVE,Constants.ACTIVE});
	}


	@Override
	public Long getActivePurchaseRowCount() throws Exception {
		return jdbcTemplate.queryForObject(QueryConstants.COUNT_ACTIVE_PURCHASE,Long.class,new Object[]{Constants.ACTIVE,Constants.ACTIVE});
	}


	@Override
	public Long getActiveFaultRowCount() throws Exception {
		return jdbcTemplate.queryForObject(QueryConstants.COUNT_ACTIVE_FAULT,Long.class,new Object[]{Constants.ACTIVE,Constants.ACTIVE});
	}


	@Override
	public List<Content> listAllSale(int strtRow,int endRow) {
		List<Content> salesList = null;
		try{
			salesList = jdbcTemplate.query(QueryConstants.LIST_ALL_SALES,new SalesRowMapper(),new Object[]{Constants.ACTIVE,Constants.ACTIVE,endRow,strtRow});
		}catch(Exception e){
			e.printStackTrace();
		}
		return salesList;
	}


	@Override
	public List<Content> listAllPurchase(int strtRow,int endRow) {
		List<Content> purchaseList = null;
		try{
			purchaseList = jdbcTemplate.query(QueryConstants.LIST_ALL_PURCHASE,new PurchaseRowMapper(),new Object[]{Constants.ACTIVE,Constants.ACTIVE,endRow,strtRow});
		}catch(Exception e){
			e.printStackTrace();
		}
		return purchaseList;
	}


	@Override
	public List<Content> listAllFault(int strtRow,int endRow) {
		List<Content> faultList = null;
		try{
			faultList = jdbcTemplate.query(QueryConstants.LIST_ALL_FAULT,new FaultRowMapper(),new Object[]{Constants.ACTIVE,Constants.ACTIVE,endRow,strtRow});
		}catch(Exception e){
			e.printStackTrace();
		}
		return faultList;
	}
	
	
}
