package com.curious365.ifa.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.curious365.ifa.common.Constants;
import com.curious365.ifa.dto.Accounts;
import com.curious365.ifa.dto.Transaction;
import com.curious365.ifa.exceptions.NoRecordFound;
import com.curious365.ifa.service.AccountingService;

@Controller
public class AccountingController {
	private Log log = LogFactory.getLog(CustomerController.class);
	
	public AccountingService getAccountingService() {
		return accountingService;
	}

	public void setAccountingService(AccountingService accountingService) {
		this.accountingService = accountingService;
	}
	
	@Autowired
	private AccountingService accountingService;
	
	@RequestMapping(value = "/customerAccountSheet", method=RequestMethod.GET)
	public ModelAndView listCustomers(@RequestParam("pageno")int pageNo,@RequestParam("customername")String customerName){
		log.debug("entering..");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("customeraccountsheet");
		mav.addObject("pageNo", pageNo);
		mav.addObject("customerName",customerName);
		int recPerPage=5;
		int strtRow=(pageNo*recPerPage)-recPerPage;
		int endRow=(pageNo*recPerPage);
		try {
			Accounts result = accountingService.getCustomerAccountDetails(customerName, strtRow, endRow);
			mav.addObject("accounts", result);
		} catch (NoRecordFound nrf){
			mav.setViewName("norecordfound");
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		};
		return mav;
	}
	
	@RequestMapping(value = "/addTransaction", method=RequestMethod.GET)
	public ModelAndView addTransactionView(){
		log.debug("entering..");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("addtransaction");
		return mav;
	}
	
	@RequestMapping(value = "/addTransaction", method=RequestMethod.POST)
	public ModelAndView createTransaction(@ModelAttribute Transaction record){
		log.debug("entering.."+ record);
		String dateString=null;
		/* current date */
		Date date = new Date();
		SimpleDateFormat formatter= 
		new SimpleDateFormat("dd/MMM/yyyy");
		String dateNow = formatter.format(date.getTime());
		/* prev date */
		int MILLIS_IN_DAY = 1000 * 60 * 60 * 24;
		String datePrev = formatter.format(date.getTime() - MILLIS_IN_DAY);
		
		if(record.getTransactionDateAlt().equalsIgnoreCase("today"))
		{
			dateString=dateNow;
		}else if(record.getTransactionDateAlt().equalsIgnoreCase("yesterday"))
		{
			dateString=datePrev;
		}else
		{
			DateFormat newformatter ; 
			Date newdate = null ; 
			newformatter = new SimpleDateFormat("dd/MM/yyyy");
			try {
				newdate = (Date)newformatter.parse(record.getTransactionDate());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			dateString=formatter.format(newdate);
		}
		record.setTransactionDate(dateString);
		ModelAndView mav = new ModelAndView();
		log.info("printing "+record);
		if(accountingService.createTransaction(record)){
			mav.setViewName("redirect:/customerAccountSheet?pageno="
					+ Constants.DEFAULT_PAGE_NO + "&customername="
					+ record.getTransactionCustomerName());
		}else{
			//if transaction not successful
			mav.setViewName("error");
		}
		return mav;
	}
	
	@RequestMapping(value = "/showSalesSheet", method=RequestMethod.GET)
	public ModelAndView showSalesSheet(){
		log.debug("entering..");
		ModelAndView mav = new ModelAndView();
		mav.addObject("transactionRecordId", 0);
		mav.addObject("pageNo", 0);
		mav.setViewName("salessheet");
		return mav;
	}
	
}
