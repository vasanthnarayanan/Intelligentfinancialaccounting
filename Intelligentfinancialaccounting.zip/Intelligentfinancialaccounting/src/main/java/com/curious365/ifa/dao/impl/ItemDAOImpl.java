package com.curious365.ifa.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.curious365.ifa.common.Constants;
import com.curious365.ifa.common.QueryConstants;
import com.curious365.ifa.dao.ItemDAO;

@Service
public class ItemDAOImpl implements ItemDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}


	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public List<String> listItemLike(String query) {
		List<String> items = new ArrayList<String>();
		try{
			items = jdbcTemplate.queryForList(QueryConstants.LIST_CUSTOMERS_LIKE, String.class,new Object[]{Constants.ACTIVE,query});			
		}catch(Exception e){
			
		}
		return items;
	}

}
