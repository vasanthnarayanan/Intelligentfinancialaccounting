package com.curious365.ifa.controller.rest;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.curious365.ifa.service.ItemService;

@RestController
public class ItemRestController {
	private Log log = LogFactory.getLog(CustomerRestController.class);
	
	@Autowired
	private ItemService itemService;
	
	@RequestMapping("/listItemsLike")
	public Map<String,Object> populateAutocomplete(@RequestParam("query") String query){
		log.debug("entering..");
		return itemService.populateAutocomplete(query);
	}

}
